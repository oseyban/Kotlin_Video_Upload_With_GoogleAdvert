package com.os.duzkoyseracilikupload
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore.Images.Media
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.os.duzkoyseracilikupload.databinding.VideoyukleBinding
import java.util.*

class VideoYukleActivity : AppCompatActivity() {

    var secilenResim : Uri?=null
    var secilenBitmap : Bitmap?=null
    private lateinit var storage:FirebaseStorage
    private lateinit var database:FirebaseFirestore
    private lateinit var binding: VideoyukleBinding
    var db=FirebaseFirestore.getInstance()

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // videoyukle.xml dosyasını bağla (inflate) et
        binding = VideoyukleBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        storage= FirebaseStorage.getInstance()
        database= FirebaseFirestore.getInstance()
        // Video yükleme ekranı ile ilgili diğer işlemleri burada yapabilirsiniz.

    }

    fun kaydet(view:View){
        //depo işlemleri
        val uuid= UUID.randomUUID()
        val referance=storage.reference
        val gorselismi="yuklenenResim+${uuid}.jpg"
        val gorselReference=referance.child("images").child(gorselismi)
        //println("kaydet düğmesine basıldı")
        if(secilenResim !=null) {
            gorselReference.putFile(secilenResim!!).addOnSuccessListener { taskSnapshot ->
          //      println("yuklendi")
                val yuklenenGorsel=FirebaseStorage.getInstance().reference.child("images").child(gorselismi)
                yuklenenGorsel.downloadUrl.addOnSuccessListener { uri ->
                    val indirmeUrl=uri.toString()
                    val yukleyiciAdi=findViewById<EditText>(R.id.editText)
                    val videoyukleyen=yukleyiciAdi.text.toString()
                    val yorum=findViewById<EditText>(R.id.editTextMultiLine)
                    val yukleyiciYorumu=yorum.text.toString()
                    val yuklemetarihi=Timestamp.now()

                    //veritabanı işlemleri
                    val postHasMap= hashMapOf<String,Any>()
                    postHasMap.put("gorselulr", indirmeUrl)
                    postHasMap.put("videoYukleyen", videoyukleyen)
                    postHasMap.put("yükleyenYorumu", yukleyiciYorumu)
                    postHasMap.put("yuklemeTarihi", yuklemetarihi)


                    db.collection("videoYukleme").add(postHasMap).addOnCompleteListener{task ->
                        if(task.isSuccessful){
                            Toast.makeText(this,"Tebrikler, Video Başarıyla Yüklendi.",Toast.LENGTH_LONG).show()
                            finish()
                        }
                    }.addOnFailureListener { exception ->
                        Toast.makeText(applicationContext,exception.localizedMessage,Toast.LENGTH_LONG).show()
                    }
                }
            }.addOnFailureListener { exception ->
                    println("hatalı yükleme")
                }
        }


    }


    fun requestStoragePermission() {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // İzin daha önce verilmemişse, izin iste
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),1)
            //ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_STORAGE_PERMISSION)
        } else {
            // İzin zaten verildi, işlemleri yapabilirsiniz.
            val galeriIntent=Intent(Intent.ACTION_PICK, Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(galeriIntent,2)

        }
    }

    fun upload(view:View){
        val REQUEST_STORAGE_PERMISSION = 1

        // İzin isteme sonucunu işleyen metot
        fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
            if (requestCode == REQUEST_STORAGE_PERMISSION) {
                if (grantResults.size>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // İzin verilmiş, işlemleri yapabilirsiniz.
                    val galeriIntent=Intent(Intent.ACTION_PICK, Media.EXTERNAL_CONTENT_URI)
                    startActivityForResult(galeriIntent,2)

                } else {
                    // İzin reddedilmiş, gerekirse kullanıcıyı bilgilendirin.
                }
            }
            //onrequest
            super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        }
        //uploa
        requestStoragePermission()

    }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == Activity.RESULT_OK && data != null) {
            secilenResim = data.data
            if (secilenResim != null) {

                if (Build.VERSION.SDK_INT >= 28) {
                    val kaynak = ImageDecoder.createSource(this.contentResolver, secilenResim!!)
                    secilenBitmap = ImageDecoder.decodeBitmap(kaynak)
                    val imageView = findViewById<ImageButton>(R.id.imageButton)
                    imageView.setImageBitmap(secilenBitmap)
                } else {
                    // Android 9 (API seviyesi 28) veya üstü değilse, eski yöntemle devam et
                    @Suppress("DEPRECATION")
                    secilenBitmap = Media.getBitmap(this.contentResolver, secilenResim)
                    val imageView = findViewById<ImageButton>(R.id.imageButton)
                    imageView.setImageBitmap(secilenBitmap)
                }
            }
        }
    }



}
